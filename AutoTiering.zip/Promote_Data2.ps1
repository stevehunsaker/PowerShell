# Script to be called by a Task to change a vDisk profile

# import the DataCore Powershell library
import-module "c:\Program files\Datacore\SANsymphony\Datacore.Executive.cmdlets.dll"

# Because the Task scheduler does not pass arguments along with the script call the arguments are send here
c:\install\ps-scripts\alter-vd-profile.ps1 "Data2 (N)" "Critical"