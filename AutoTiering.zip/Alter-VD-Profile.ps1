# Script to be called by a script which is called by a task

# import the DataCore Powershell library
import-module "c:\Program files\Datacore\SANsymphony\Datacore.Executive.cmdlets.dll"

# connect to the local DataCore Server
connect-dcsserver
# change vDisk profile for vDisk $args[0] to profile $args[1]
set-dcsvirtualdiskproperties -virtualdisk $args[0] -storageprofile $args[1]
# disconnect from local DataCore Server
disconnect-dcsserver