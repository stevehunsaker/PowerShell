Import-Module "C:\Program Files\DataCore\SANsymphony\DataCore.Executive.Cmdlets.dll"
Connect-DcsServer -Server DATACORE01 -UserName Administrator -Password DataCore$
Enable-DcsServerWriteCache -Server DATACORE01
Disconnect-DcsServer
