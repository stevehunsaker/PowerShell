Disable/Enable DataCore cache
Extract the zip on C:\SCRIPTS
The UPS agent running on SSY-V as to run the script disable-cache.bat on "Power Failure" event
and run enable-cache.bat on "Power Restore" event
Edit each ps1 files and specify the SSY-V name server
In the example sds 1 is DATACORE01 and sds 2 is DATACORE02
